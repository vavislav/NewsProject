import getArticles from "./api.js";

let addSlides = function (data) {
    let slide = document.querySelector("ul.slide");
    function addSlide(data) {
        let element = document.createElement('li');
        element.appendChild(document.createElement('span'));
        element.querySelector("span").innerText = data.title;
        slide.append(element);
    }
    data.forEach(element => {
        addSlide(element);
    })
};
let initSlider = function() {

    let wrapper = document.querySelector(".news-slider");
    let sliderItems = wrapper.querySelectorAll('li');
    let slide = wrapper.querySelector("ul.slide");
    let index = 0;
    function transform() {
        slide.style.transition = "";
        slide.style.transition = "all 1s ease-in-out";
        if(index < sliderItems.length - 1) {
            index++;
            slide.style.transform = "translate("+(-index * sliderItems[0].offsetWidth + 7) +"px, -50%)";
        }
        else {
            slide.style.transition = "none";
            index = 0;
            slide.style.transform = "transform: translate("+ -index * sliderItems[0].offsetWidth +"px, -50%)";
        }
    }
    setInterval(transform, 3000)
};
let initNews = function(data) {
  let setupElement = function (title, src, srcToImage, published) {
      let date = new Date(published);

      let elementHTML = `<div class="image"><a href="${src}"><img src="${srcToImage}"/></a></div>
                    <div class="title"><a href="${src}">
                        <h3>${title}</h3></a></div>
                    <div class="social">
                      <div class="seen">
                        <div class="icon"><i class="far fa-eye"></i></div>
                        <p class="number">${date.toDateString()}</p>
                      </div>
                      <div class="like">
                        <p class="number">4</p>
                        <div class="icon"><i class="fas fa-heart" style="color:pink;"></i></div>
                      </div>
                    </div>`;
      let element = document.createElement('div');
      element.classList.add('block');
      element.innerHTML = elementHTML;
      return element;
  };
  let wrapper = document.getElementById("wrapper");
  data.forEach(news => {
      wrapper.appendChild(setupElement(news.title, news.url, news.urlToImage, news.publishedAt))
    });
};
getArticles().then(response =>
{
   addSlides(response.articles);
   initSlider();
   initNews(response.articles);
});

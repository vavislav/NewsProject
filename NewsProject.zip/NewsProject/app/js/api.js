export default async function getArticles() {
    let url = 'https://newsapi.org/v2/top-headlines?' +
        'country=ua&' +
        'apiKey=28cfd6d0bd714b92a8b560b4b0c396d1';
    let response = await fetch(url);
    let data = await response.json();
    data = JSON.stringify(data);
    data = JSON.parse(data);
    return data;
}


// I need Watch(to refresh all my files)
    //  Now I need to check my files
    //  If it's changed, I should compile my SASS + autoprefixer
        // Destination in css/
    //  Then I have to refresh everything
// I need Backup(to save them properly)
    // Send all files into new place
    // Minimize assets
// I need Git(to save files to repository and sent on the server)
    // Send all files to repository
    // Minimize css/
    // Commit
    // Push

/*  end of rules  */

/*  connecting of the scripts  */

var gulp         = require('gulp'),
    pug          = require('gulp-pug'),
    sass         = require('gulp-sass'),
    browserSync  = require('browser-sync'),
    del          = require('del'),
    imagemin     = require('gulp-imagemin'),
    pngquant     = require('imagemin-pngquant-gfw'),
    autoprefixer = require('gulp-autoprefixer'),
    git          = require('gulp-git');


    /*  tasks  */


    gulp.task('browser-sync', () => { // create a server

        browserSync({
            server: {
                baseDir: 'app',
            },
            notify: false,
            ui: {
                port: 8080,
                weinre: {
                    port: 8080
                }
            },
            port: 8080
        });

    });

    gulp.task('pug', () => {
        return gulp.src('app/*.pug')
        .pipe(pug({
          filename: 'index',
          pretty: true,
        })).pipe(gulp.dest('app'))
            .pipe(browserSync.reload({
                stream: true
            }));
      });


    gulp.task('sass', () => { //render sass and reloadBR on ''

        return gulp.src('app/sass/main.sass').
            pipe(sass()).
            pipe(autoprefixer(['last 15 versions', '> 1%', 'ie 8', 'ie 7'], {
                cascade: true
            })).
            pipe(gulp.dest('app/css')).
            pipe(browserSync.reload({
                stream: true
            }));

    });


    gulp.task('html', () => { //reloadBr on ''

        return gulp.src('app/**/*.html').
            pipe(browserSync.reload({
                stream: true
            }));

    });


    gulp.task('scripts', () => { //reloadBr on ''

        return gulp.src('app/**/*.js').
            pipe(browserSync.reload({
                stream: true
            }));

    });

    gulp.task('img', () => {

        return gulp.src('app/assets/**/*').
            pipe(imagemin({
                interlaced: true,
                progressive: true,
                svgoPlugins: [{
                    removeViewBox: false
                }],
                use: [pngquant()]
            })).pipe(gulp.dest('backup/assets'));

    });


    gulp.task('watch', () => { //watch files
        gulp.watch('app/**/*.pug', gulp.parallel('pug'));
        gulp.watch('app/**/*.sass', gulp.parallel('sass'));
        gulp.watch('app/**/*.html', gulp.parallel('html'));
        gulp.watch('app/**/*.js'  , gulp.parallel('scripts'));

    });

    gulp.task('default', gulp.parallel('pug','sass', 'browser-sync', 'watch')); //routine task


    gulp.task('preBackup', async () => { //backup everything

        (async () => { //deleting of the folder 'backup'
            const deletedPaths = await del(['backup'], {
                dryRun: true
            });
        })();

        /* transporting of everything */
        gulp.src('app/*.pug').pipe(gulp.dest('backup'));
        gulp.src('app/*.html').pipe(gulp.dest('backup'));
        gulp.src('app/pages/*.html').pipe(gulp.dest('backup/pages'));
        gulp.src('app/css/*.css').pipe(gulp.dest('backup/css'));
        gulp.src('app/sass/main.sass').pipe(gulp.dest('backup/sass'));
        gulp.src('app/js/*.js').pipe(gulp.dest('backup/js'));
        gulp.src('app/assets/*.*').pipe(gulp.dest('backup/assets'));
        gulp.src('app/fonts/*.*').pipe(gulp.dest('backup/fonts'));
    });

    gulp.task('backup', gulp.series('preBackup', 'img'));
